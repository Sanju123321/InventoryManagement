<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <?php
                    $user = auth()->user();
                    $currentUrl = url()->current();
                ?>

                <?php if($user->isSuperAdmin()): ?>
                    
                    <div class="sb-sidenav-menu-heading">SuperAdmin</div>
                    <a class="nav-link <?php echo e(request()->is('superadmin/dashboard') ? 'active' : ''); ?>"
                        href="<?php echo e(url('/superadmin/dashboard')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        Dashboard
                    </a>
                    <a class="nav-link <?php echo e(request()->is('superadmin/companies*') ? 'active' : ''); ?>"
                        href="<?php echo e(url('/superadmin/companies')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-building"></i></div>
                        Companies
                    </a>
                    <a class="nav-link <?php echo e(request()->is('superadmin/users*') ? 'active' : ''); ?>"
                        href="<?php echo e(url('/superadmin/users')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                        Users
                    </a>
                    <a class="nav-link <?php echo e(request()->routeIs('superadmin.activity-log') ? 'active' : ''); ?>"
                        href="<?php echo e(route('superadmin.activity-log')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-history"></i></div>
                        Activity Log
                    </a>
                    <a class="nav-link <?php echo e(request()->routeIs('superadmin.analytics') ? 'active' : ''); ?>"
                        href="<?php echo e(route('superadmin.analytics')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-chart-bar"></i></div>
                        Analytics
                    </a>
                    <a class="nav-link <?php echo e(request()->routeIs('superadmin.announcements*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('superadmin.announcements')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-bullhorn"></i></div>
                        Announcements
                    </a>
                    <a class="nav-link <?php echo e(request()->routeIs('superadmin.health*') ? 'active' : ''); ?>"
                        href="<?php echo e(route('superadmin.health')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-heartbeat"></i></div>
                        System Health
                    </a>
                <?php else: ?>
                    
                    <div class="sb-sidenav-menu-heading">Core</div>
                    <a class="nav-link <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>"
                        href="<?php echo e(url('/dashboard')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        Dashboard
                    </a>

                    
                    <?php if($user->hasRole(['admin', 'inventory_admin'])): ?>
                        <div class="sb-sidenav-menu-heading">Inventory</div>
                        <a class="nav-link <?php echo e(request()->is('inventory*') ? 'active' : ''); ?>"
                            href="<?php echo e(url('/inventory')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-boxes-stacked"></i></div>
                            Inventory
                        </a>
                        <a class="nav-link <?php echo e(request()->is('products*') ? 'active' : ''); ?>"
                            href="<?php echo e(url('/products')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-box"></i></div>
                            Products
                        </a>
                        <a class="nav-link <?php echo e(request()->is('materials*') ? 'active' : ''); ?>"
                            href="<?php echo e(url('/materials')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-cubes"></i></div>
                            Raw Materials
                        </a>
                        <a class="nav-link <?php echo e(request()->is('bom*') ? 'active' : ''); ?>" href="<?php echo e(url('/bom')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-list-check"></i></div>
                            Bill of Materials
                        </a>

                        <div class="sb-sidenav-menu-heading">Production</div>
                        <a class="nav-link <?php echo e(request()->is('production*') ? 'active' : ''); ?>"
                            href="<?php echo e(url('/production')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-industry"></i></div>
                            Production Logs
                        </a>
                        <a class="nav-link <?php echo e(request()->is('reports*') ? 'active' : ''); ?>"
                            href="<?php echo e(url('/reports')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-line"></i></div>
                            Reports & Analytics
                        </a>
                    <?php endif; ?>

                    
                    <?php if($user->hasRole(['admin', 'sales_admin'])): ?>
                        <div class="sb-sidenav-menu-heading">Sales</div>
                        <a class="nav-link <?php echo e(request()->is('sales/dashboard') ? 'active' : ''); ?>"
                            href="<?php echo e(url('/sales/dashboard')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-cash-register"></i></div>
                            Sales Dashboard
                        </a>
                        <a class="nav-link <?php echo e(request()->is('customers*') ? 'active' : ''); ?>"
                            href="<?php echo e(url('/customers')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                            Customers
                        </a>
                        <a class="nav-link <?php echo e(request()->is('sales/orders*') ? 'active' : ''); ?>"
                            href="<?php echo e(url('/sales/orders')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-file-invoice"></i></div>
                            Sales Orders
                        </a>
                        <?php if($user->isAdmin()): ?>
                        <a class="nav-link <?php echo e(request()->is('sales/product-costs*') ? 'active' : ''); ?>"
                            href="<?php echo e(url('/sales/product-costs')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-tags"></i></div>
                            Product Pricing
                        </a>
                        <a class="nav-link <?php echo e(request()->is('sales/reports*') ? 'active' : ''); ?>"
                            href="<?php echo e(url('/sales/reports/products')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-bar"></i></div>
                            Product Report
                        </a>
                        <?php endif; ?>
                    <?php endif; ?>

                    
                    <?php if($user->isAdmin()): ?>
                        <div class="sb-sidenav-menu-heading">Administration</div>
                        <a class="nav-link <?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>"
                            href="<?php echo e(route('users.index')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-user-shield"></i></div>
                            User Management
                        </a>
                        <a class="nav-link <?php echo e(request()->routeIs('analytics.index') ? 'active' : ''); ?>"
                            href="<?php echo e(route('analytics.index')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-bar"></i></div>
                            Analytics
                        </a>
                        <a class="nav-link <?php echo e(request()->routeIs('activity-log.index') ? 'active' : ''); ?>"
                            href="<?php echo e(route('activity-log.index')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-history"></i></div>
                            Activity Log
                        </a>
                    <?php endif; ?>

                <?php endif; ?>
            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            <?php echo e(auth()->user()->name); ?>

            <span class="badge <?php echo e(auth()->user()->roleBadgeClass()); ?> ms-1" style="font-size:.65rem;">
                <?php echo e(auth()->user()->roleLabel()); ?>

            </span>
            <?php if(auth()->user()->company): ?>
                <div class="small text-muted"><?php echo e(auth()->user()->company->company_name); ?></div>
            <?php endif; ?>
        </div>
    </nav>
</div>
<?php /**PATH C:\xampp\htdocs\inventoryManagementApril\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>