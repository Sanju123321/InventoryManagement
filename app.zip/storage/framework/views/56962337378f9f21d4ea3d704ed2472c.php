﻿

<?php $__env->startSection('title', 'Dashboard - Kemtex ERP'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>
    <div class="row">
        <div class="col-6 col-xl-3">
            <div class="card bg-primary text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="small">Total Products</div>
                            <div class="fs-4 fw-bold"><?php echo e($totalProducts ?? 0); ?></div>
                        </div>
                        <i class="fas fa-box fa-2x"></i>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?php echo e(url('/products')); ?>">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="card bg-warning text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="small">Raw Materials</div>
                            <div class="fs-4 fw-bold"><?php echo e($totalMaterials ?? 0); ?></div>
                        </div>
                        <i class="fas fa-cubes fa-2x"></i>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?php echo e(url('/materials')); ?>">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="small">Production Today</div>
                            <div class="fs-4 fw-bold"><?php echo e($productionToday ?? 0); ?></div>
                        </div>
                        <i class="fas fa-industry fa-2x"></i>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?php echo e(url('/production')); ?>">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-xl-3">
            <div class="card bg-danger text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="small">Low Stock Alerts</div>
                            <div class="fs-4 fw-bold"><?php echo e($lowStockCount ?? 0); ?></div>
                        </div>
                        <i class="fas fa-exclamation-triangle fa-2x"></i>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?php echo e(url('/reports/low-stock')); ?>">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-industry me-1"></i>
                    Recent Production Logs
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-bordered table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Qty Produced</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $recentProduction ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($log->product->name); ?></td>
                                        <td><?php echo e($log->quantity_produced); ?></td>
                                        <td><?php echo e($log->production_date->format('Y-m-d')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3" class="text-center">No production logs yet.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-exclamation-triangle me-1"></i>
                    Low Stock Materials
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-bordered table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>Material</th>
                                    <th>Unit</th>
                                    <th>Stock Qty</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $lowStockMaterials ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($material->name); ?></td>
                                        <td><?php echo e($material->unit); ?></td>
                                        <td><span class="badge bg-danger"><?php echo e($material->stock_qty); ?></span></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3" class="text-center">No low stock alerts.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-12">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-chart-bar me-1"></i> Product Sales & Profit Report</span>
                    <a href="<?php echo e(url('/sales/reports/products')); ?>" class="btn btn-sm btn-outline-primary">View Full
                        Report</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-sm mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th>Product</th>
                                    <th>SKU</th>
                                    <th>Production Cost</th>
                                    <th>Selling Price</th>
                                    <th>Total Produced</th>
                                    <th>Total Sold</th>
                                    <th>Available Stock</th>
                                    <th>Total Revenue</th>
                                    <th>Total Profit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $productReport ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($item['product']->name); ?></td>
                                        <td><?php echo e($item['product']->sku); ?></td>
                                        <td>â‚¹<?php echo e($item['cost'] ? number_format($item['cost']->production_cost, 2) : '-'); ?>

                                        </td>
                                        <td>â‚¹<?php echo e($item['cost'] ? number_format($item['cost']->selling_price, 2) : '-'); ?>

                                        </td>
                                        <td><?php echo e($item['total_produced']); ?></td>
                                        <td><?php echo e($item['total_sold']); ?></td>
                                        <td>
                                            <?php if($item['available_stock'] <= 0): ?>
                                                <span class="badge bg-danger"><?php echo e($item['available_stock']); ?></span>
                                            <?php elseif($item['available_stock'] <= 10): ?>
                                                <span class="badge bg-warning"><?php echo e($item['available_stock']); ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-success"><?php echo e($item['available_stock']); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>â‚¹<?php echo e(number_format($item['total_revenue'], 2)); ?></td>
                                        <td>
                                            <?php if($item['total_profit'] >= 0): ?>
                                                <span
                                                    class="text-success fw-bold">â‚¹<?php echo e(number_format($item['total_profit'], 2)); ?></span>
                                            <?php else: ?>
                                                <span
                                                    class="text-danger fw-bold">-â‚¹<?php echo e(number_format(abs($item['total_profit']), 2)); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="9" class="text-center">No products found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                            <?php if(collect($productReport ?? [])->count() > 0): ?>
                                <tfoot>
                                    <tr class="fw-bold">
                                        <td colspan="5">Totals</td>
                                        <td><?php echo e(collect($productReport)->sum('total_sold')); ?></td>
                                        <td></td>
                                        <td>â‚¹<?php echo e(number_format(collect($productReport)->sum('total_revenue'), 2)); ?></td>
                                        <td>â‚¹<?php echo e(number_format(collect($productReport)->sum('total_profit'), 2)); ?></td>
                                    </tr>
                                </tfoot>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-12">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-exchange-alt me-1"></i>
                    Recent Inventory Transactions
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-bordered table-sm mb-0">
                            <thead>
                                <tr>
                                    <th>Material</th>
                                    <th>Type</th>
                                    <th>Quantity</th>
                                    <th>Stock After</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $recentTransactions ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $txn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($txn->material->name); ?></td>
                                        <td>
                                            <?php if($txn->type === 'in'): ?>
                                                <span class="badge bg-success">In</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Out</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($txn->quantity); ?></td>
                                        <td><?php echo e($txn->stock_after); ?></td>
                                        <td><?php echo e($txn->created_at->format('Y-m-d')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">No transactions yet.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventoryManagementApril\resources\views/dashboard.blade.php ENDPATH**/ ?>