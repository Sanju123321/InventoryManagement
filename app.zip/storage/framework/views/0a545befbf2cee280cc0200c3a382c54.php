

<?php $__env->startSection('title', 'Sign In — Kemtex Management System'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Welcome back</h2>
    <p class="auth-subtitle">Sign in to continue to your account</p>

    <?php if($errors->any()): ?>
        <div class="alert-auth">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert-auth" style="background:#f0fdf4;border-color:#bbf7d0;color:#16a34a;"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(url('/login')); ?>">
        <?php echo csrf_field(); ?>

        <div class="field-group">
            <label for="inputEmail">Email address</label>
            <div class="input-wrap <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <i class="fas fa-envelope input-ico"></i>
                <input id="inputEmail" name="email" type="email" placeholder="you@company.com"
                    value="<?php echo e(old('email')); ?>" required autocomplete="email" />
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color:#e74c3c;font-size:0.8rem;margin-top:4px;"><i
                        class="fas fa-exclamation-circle me-1"></i><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="field-group">
            <label for="inputPassword">Password</label>
            <div class="input-wrap">
                <i class="fas fa-lock input-ico"></i>
                <input id="inputPassword" name="password" type="password" placeholder="••••••••" required minlength="8"
                    autocomplete="current-password" />
                <span class="toggle-pw" id="togglePw" title="Show/hide password">
                    <i class="fas fa-eye" id="togglePwIcon"></i>
                </span>
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color:#e74c3c;font-size:0.8rem;margin-top:4px;"><i
                        class="fas fa-exclamation-circle me-1"></i><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="row-between">
            <label class="remember-label">
                <input type="checkbox" name="remember" value="1" />
                Remember me
            </label>
        </div>

        <button type="submit" class="btn-signin">
            <i class="fas fa-sign-in-alt me-2"></i> Sign In
        </button>
    </form>

    <p class="auth-footer-text">
        Don't have an account? <a href="<?php echo e(url('/register')); ?>">Create one</a>
    </p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.getElementById('togglePw').addEventListener('click', function() {
            const input = document.getElementById('inputPassword');
            const icon = document.getElementById('togglePwIcon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventoryManagementApril\resources\views/auth/login.blade.php ENDPATH**/ ?>