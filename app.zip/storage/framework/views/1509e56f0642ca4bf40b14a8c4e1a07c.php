<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">&copy; <?php echo e(date('Y')); ?> Kemtex Management System. All rights reserved.</div>
            <div>
                <a href="#">Privacy Policy</a>
                &middot;
                <a href="#">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\inventoryManagementApril\resources\views/layouts/footer.blade.php ENDPATH**/ ?>